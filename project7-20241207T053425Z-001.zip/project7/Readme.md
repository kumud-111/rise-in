# Subscription Service

# Deployed ID: 0x8d0bfaf284186be3505219224b31494e8a71beccc9b4bcac7ba1bb3c77fe2e33
![alt text](image.png)

## Project Description
The Subscription Service smart contract automates recurring payments for subscription-based services such as streaming platforms or online courses. Users can subscribe for specific periods, and the contract ensures timely payment collection while granting access to the service.

## Project Vision
To create a seamless experience for users to manage their subscriptions, ensuring automated billing and access to tiered service levels with easy options for upgrades or cancellations.

## Key Features
- **Automated Subscription Management**: Users can create and renew subscriptions with a single transaction.
- **Tiered Subscription Levels**: Support for different tiers, allowing users to choose a plan that fits their needs.
- **Recurring Payments**: Automates the collection of payments upon subscription renewal, minimizing user effort.
- **Flexible Duration**: Users can specify the duration of their subscriptions, making it easy to manage short-term or long-term commitments.
